import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Zap, 
  Skull, 
  TrendingUp, 
  Coins, 
  Heart, 
  Sword, 
  AlertCircle, 
  CheckCircle2, 
  Home, 
  Gamepad2, 
  ListChecks,
  RefreshCcw,
  X,
  Share2,
  Quote,
  Smile,
  Frown,
  Meh,
  CalendarDays
} from 'lucide-react';

// --- Types ---
type CheckIn = {
  date: string;
  mood: 'great' | 'okay' | 'struggling';
  note: string;
};

type GameState = {
  startDate: string | null;
  xp: number;
  health: number;
  defeatedEnemies: string[];
  buffUntil: string | null;
  checkIns: CheckIn[];
};

type Emoji = {
  id: number;
  type: 'good' | 'bad';
  char: string;
  x: number;
  y: number;
  speed: number;
};

// --- Constants ---
type Enemy = {
  id: string;
  name: string;
  xp: number;
  desc: string;
};

const HIDDEN_ENEMIES: Enemy[] = [
  { id: 'maltodextrin', name: 'Maltodextrin', xp: 50, desc: 'Often found in "sugar-free" snacks.' },
  { id: 'dextrose', name: 'Dextrose', xp: 50, desc: 'Pure glucose, spikes insulin instantly.' },
  { id: 'hfcs', name: 'High Fructose Corn Syrup', xp: 100, desc: 'The ultimate metabolic disruptor.' },
  { id: 'sucralose', name: 'Sucralose', xp: 30, desc: 'Artificial sweetener that can affect gut health.' },
  { id: 'agave', name: 'Agave Nectar', xp: 40, desc: 'Marketed as healthy, but extremely high in fructose.' },
];

const DAILY_SAVINGS = 5;

const MOTIVATIONAL_QUOTES = [
  "Sugar is the only drug we give to children to celebrate.",
  "Your body is a temple, not a graveyard for processed sugar.",
  "The first 3 days are for the body, the next 18 are for the mind.",
  "Discipline is choosing between what you want now and what you want most.",
  "Every time you say no to a craving, you say yes to your future self.",
  "You are stronger than a molecule of glucose.",
  "The sweetness of health lasts longer than the sweetness of a donut.",
  "Energy comes from within, not from a candy bar.",
];

// --- Components ---

const MotivationalQuote = () => {
  const [quote, setQuote] = useState("");

  useEffect(() => {
    // Select quote based on the day of the year to keep it consistent for 24h
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const day = Math.floor(diff / oneDay);
    setQuote(MOTIVATIONAL_QUOTES[day % MOTIVATIONAL_QUOTES.length]);
  }, []);

  return (
    <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl relative overflow-hidden group">
      <Quote className="absolute -top-2 -left-2 w-12 h-12 text-amber-500/10 group-hover:text-amber-500/20 transition-colors" />
      <p className="text-slate-300 italic text-sm relative z-10 leading-relaxed">
        "{quote}"
      </p>
    </div>
  );
};

const ShareButton = ({ text, title }: { text: string; title: string }) => {
  const handleShare = async () => {
    const shareData = {
      title: 'SugarSlayer Quest',
      text: text,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      // Fallback to Twitter
      const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text + " " + window.location.href)}`;
      window.open(twitterUrl, '_blank');
    }
  };

  return (
    <button 
      onClick={handleShare}
      className="flex items-center gap-2 text-xs font-bold text-amber-500 hover:text-amber-400 transition-colors uppercase tracking-widest"
    >
      <Share2 size={14} /> Share Milestone
    </button>
  );
};

const CheckInModal = ({ onSave, onClose }: { onSave: (mood: CheckIn['mood'], note: string) => void; onClose: () => void }) => {
  const [mood, setMood] = useState<CheckIn['mood']>('okay');
  const [note, setNote] = useState('');

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-6"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-sm space-y-6 shadow-2xl"
      >
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-bold text-white">Daily Check-in</h3>
          <button onClick={onClose} className="text-slate-500 hover:text-white"><X size={20} /></button>
        </div>

        <div className="space-y-4">
          <p className="text-sm text-slate-400">How are you feeling today?</p>
          <div className="flex justify-between gap-2">
            {(['struggling', 'okay', 'great'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMood(m)}
                className={`flex-1 py-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${
                  mood === m 
                    ? 'bg-amber-500/10 border-amber-500 text-amber-500' 
                    : 'bg-slate-800 border-slate-700 text-slate-500 hover:border-slate-600'
                }`}
              >
                {m === 'great' && <Smile size={24} />}
                {m === 'okay' && <Meh size={24} />}
                {m === 'struggling' && <Frown size={24} />}
                <span className="text-[10px] uppercase font-bold tracking-widest">{m}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <p className="text-sm text-slate-400">Cravings overcome / Notes</p>
          <textarea 
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="e.g. Resisted the office donuts today!"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm text-white focus:outline-none focus:border-amber-500 min-h-[100px] resize-none"
          />
        </div>

        <button 
          onClick={() => onSave(mood, note)}
          className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-4 rounded-2xl transition-all active:scale-95 uppercase tracking-widest"
        >
          Record Entry
        </button>
      </motion.div>
    </motion.div>
  );
};

const ResetConfirmationModal = ({ onConfirm, onCancel }: { onConfirm: () => void; onCancel: () => void }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-6"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-slate-900 border-2 border-red-500/30 rounded-3xl p-8 w-full max-w-sm space-y-6 shadow-[0_0_50px_rgba(239,68,68,0.2)] text-center"
      >
        <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center border-2 border-red-500/20 mx-auto">
          <Skull className="text-red-500 w-10 h-10" />
        </div>
        
        <div className="space-y-2">
          <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Abandon Quest?</h3>
          <p className="text-slate-400 text-sm leading-relaxed">
            Warning: This will permanently destroy your current streak, XP, and journal entries. This action cannot be undone.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <button 
            onClick={onConfirm}
            className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-4 rounded-2xl transition-all active:scale-95 uppercase tracking-widest shadow-lg shadow-red-500/20"
          >
            Yes, Reset Progress
          </button>
          <button 
            onClick={onCancel}
            className="w-full bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-4 rounded-2xl transition-all active:scale-95 uppercase tracking-widest"
          >
            No, Keep Fighting
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};

const EnemyCard: React.FC<{ enemy: Enemy, isDefeated: boolean, onToggle: () => void }> = ({ enemy, isDefeated, onToggle }) => {
  const [isAnimating, setIsAnimating] = useState(false);

  const handleToggle = () => {
    if (!isDefeated) {
      setIsAnimating(true);
      setTimeout(() => setIsAnimating(false), 500);
    }
    onToggle();
  };

  return (
    <motion.button 
      onClick={handleToggle}
      animate={isAnimating ? {
        x: [-2, 2, -2, 2, 0],
        scale: [1, 0.98, 1],
      } : {}}
      transition={{ duration: 0.2 }}
      className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between relative overflow-hidden ${
        isDefeated 
          ? 'bg-emerald-500/10 border-emerald-500/50' 
          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
      }`}
    >
      {/* Slash Effect */}
      <AnimatePresence>
        {isAnimating && (
          <motion.div 
            initial={{ x: '-100%', y: '100%', rotate: -45 }}
            animate={{ x: '150%', y: '-150%' }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, ease: "circOut" }}
            className="absolute inset-0 bg-white/40 z-10 pointer-events-none h-2"
            style={{ top: '50%', left: '0', width: '200%' }}
          />
        )}
      </AnimatePresence>

      {/* Sparks Effect */}
      <AnimatePresence>
        {isAnimating && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0, x: '50%', y: '50%' }}
                animate={{ 
                  scale: [0, 1, 0],
                  x: `${50 + (Math.random() - 0.5) * 80}%`,
                  y: `${50 + (Math.random() - 0.5) * 80}%`
                }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
                className="absolute w-1 h-1 bg-amber-400 rounded-full"
              />
            ))}
          </div>
        )}
      </AnimatePresence>

      <div className="flex items-center gap-4">
        <div className="relative">
          {isDefeated ? (
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
            >
              <CheckCircle2 className="text-emerald-500" />
            </motion.div>
          ) : (
            <div className="w-6 h-6 rounded-full border-2 border-slate-700" />
          )}
        </div>
        <div>
          <h4 className={`font-bold transition-colors ${isDefeated ? 'text-emerald-400' : 'text-white'}`}>
            {enemy.name}
          </h4>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest">+{enemy.xp} XP</p>
        </div>
      </div>
      <AlertCircle className={`transition-colors ${isDefeated ? 'text-emerald-500/50' : 'text-slate-700'} w-4 h-4`} />
    </motion.button>
  );
};

const Vessel = ({ days }: { days: number }) => {
  let state: 'husk' | 'guardian' | 'god' = 'husk';
  if (days >= 22) state = 'god';
  else if (days >= 8) state = 'guardian';

  return (
    <div className="relative flex flex-col items-center justify-center h-80 w-full">
      {/* Aura for God State */}
      {state === 'god' && (
        <>
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.2, 0.4, 0.2],
              rotate: [0, 180, 360]
            }}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 rounded-full bg-blue-500/10 blur-3xl"
          />
          {/* Energy Particles for God State */}
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ y: 0, opacity: 0, x: (i - 2.5) * 20 }}
              animate={{ 
                y: -100, 
                opacity: [0, 1, 0],
                scale: [0.5, 1, 0.5]
              }}
              transition={{ 
                duration: 2 + Math.random() * 2, 
                repeat: Infinity, 
                delay: i * 0.4,
                ease: "easeOut"
              }}
              className="absolute bottom-20 w-1 h-1 bg-blue-400 rounded-full blur-[1px]"
            />
          ))}
        </>
      )}

      {/* Floating Animation for Guardian and God */}
      <motion.div
        animate={state === 'god' ? {
          y: [0, -15, 0],
          rotate: [-0.5, 0.5, -0.5]
        } : state === 'guardian' ? {
          y: [0, -8, 0],
        } : {
          rotate: [-1, 1, -1]
        }}
        transition={{ 
          duration: state === 'god' ? 3 : 5, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
        className="relative flex flex-col items-center"
      >
        {/* Head */}
        <motion.div 
          animate={state === 'husk' ? { 
            y: [0, 4, 0],
            rotate: [-2, 2, -2]
          } : { 
            y: [0, -2, 0] 
          }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className={`w-14 h-14 rounded-full absolute -top-16 border-4 z-20 flex items-center justify-center transition-colors duration-1000 ${
            state === 'husk' ? 'bg-slate-700 border-slate-600 grayscale' :
            state === 'guardian' ? 'bg-amber-100 border-amber-500' :
            'bg-blue-100 border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.5)]'
          }`}
        >
          {/* Eyes */}
          <div className="flex gap-3">
            <motion.div 
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ duration: 4, repeat: Infinity, times: [0, 0.95, 1], delay: 1 }}
              className={`w-2.5 h-2.5 rounded-full ${state === 'husk' ? 'bg-slate-500' : 'bg-slate-900'}`} 
            />
            <motion.div 
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ duration: 4, repeat: Infinity, times: [0, 0.95, 1], delay: 1.1 }}
              className={`w-2.5 h-2.5 rounded-full ${state === 'husk' ? 'bg-slate-500' : 'bg-slate-900'}`} 
            />
          </div>
          {/* Mouth */}
          <motion.div 
            animate={state === 'husk' ? { scaleX: [1, 1.2, 1] } : {}}
            transition={{ duration: 4, repeat: Infinity }}
            className={`absolute bottom-2 w-4 h-1 rounded-full ${state === 'husk' ? 'bg-slate-600' : 'bg-slate-800/20'}`} 
          />
        </motion.div>

        {/* Body */}
        <motion.div
          animate={state === 'husk' ? {
            scaleY: [1, 1.08, 1],
            scaleX: [1, 0.98, 1],
          } : state === 'guardian' ? {
            scaleY: [1, 1.03, 1],
          } : {
            scale: [1, 1.02, 1],
          }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className={`relative w-32 h-44 rounded-3xl border-4 flex flex-col items-center justify-end pb-4 transition-all duration-1000 z-10 ${
            state === 'husk' ? 'bg-slate-700 border-slate-600 grayscale brightness-75' :
            state === 'guardian' ? 'bg-amber-100 border-amber-500' :
            'bg-blue-100 border-blue-500'
          }`}
        >
          {/* Arms */}
          <motion.div 
            animate={state === 'husk' ? { 
              rotate: [0, 8, 0],
              y: [0, 2, 0]
            } : { 
              rotate: [-25, -15, -25] 
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className={`absolute -left-6 top-8 w-6 h-24 rounded-full border-4 origin-top transition-colors duration-1000 ${
              state === 'husk' ? 'bg-slate-700 border-slate-600' :
              state === 'guardian' ? 'bg-amber-100 border-amber-500' :
              'bg-blue-100 border-blue-500'
            }`}
          />
          <motion.div 
            animate={state === 'husk' ? { 
              rotate: [0, -8, 0],
              y: [0, 2, 0]
            } : { 
              rotate: [25, 15, 25] 
            }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className={`absolute -right-6 top-8 w-6 h-24 rounded-full border-4 origin-top transition-colors duration-1000 ${
              state === 'husk' ? 'bg-slate-700 border-slate-600' :
              state === 'guardian' ? 'bg-amber-100 border-amber-500' :
              'bg-blue-100 border-blue-500'
            }`}
          />

          {/* Husky Belly for State 1 */}
          {state === 'husk' && (
            <motion.div 
              animate={{ 
                scale: [1, 1.15, 1],
                opacity: [0.4, 0.6, 0.4]
              }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="w-24 h-24 bg-slate-600 rounded-full absolute bottom-4 opacity-50" 
            />
          )}

          {/* Willpower Vest for State 2 */}
          {state === 'guardian' && (
            <div className="w-full h-24 bg-amber-500/30 border-y-2 border-amber-500 absolute top-4 flex items-center justify-center overflow-hidden">
              <Shield className="text-amber-600 w-8 h-8" />
              <motion.div 
                animate={{ x: [-150, 250] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-12"
              />
            </div>
          )}

          {/* Muscular Definition for State 3 */}
          {state === 'god' && (
            <div className="w-full h-full flex flex-col items-center pt-4 px-2">
               <div className="w-full h-1 bg-blue-500/20 rounded mb-2" />
               <div className="w-full h-1 bg-blue-500/20 rounded mb-2" />
               <div className="w-full h-1 bg-blue-500/20 rounded mb-2" />
               <motion.div
                 animate={{ scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }}
                 transition={{ duration: 2, repeat: Infinity }}
               >
                 <Zap className="text-blue-500 w-10 h-10 mt-4" />
               </motion.div>
            </div>
          )}
        </motion.div>

        {/* Legs */}
        <div className="flex gap-8 -mt-2">
          <motion.div 
            animate={state === 'husk' ? { 
              rotate: [0, 3, 0],
              scaleY: [1, 0.95, 1]
            } : {}}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className={`w-6 h-16 rounded-full border-4 transition-colors duration-1000 ${
              state === 'husk' ? 'bg-slate-700 border-slate-600' :
              state === 'guardian' ? 'bg-amber-100 border-amber-500' :
              'bg-blue-100 border-blue-500'
            }`}
          />
          <motion.div 
            animate={state === 'husk' ? { 
              rotate: [0, -3, 0],
              scaleY: [1, 0.95, 1]
            } : {}}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className={`w-6 h-16 rounded-full border-4 transition-colors duration-1000 ${
              state === 'husk' ? 'bg-slate-700 border-slate-600' :
              state === 'guardian' ? 'bg-amber-100 border-amber-500' :
              'bg-blue-100 border-blue-500'
            }`}
          />
        </div>
      </motion.div>

      <div className="mt-12 text-center">
        <motion.h2 
          key={state}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xl font-bold text-amber-500 uppercase tracking-widest"
        >
          {state === 'husk' ? 'The Sluggish Husk' : state === 'guardian' ? 'The Guardian' : 'The Glucose God'}
        </motion.h2>
        <p className="text-slate-400 text-sm">Level {Math.floor(days / 7) + 1} Vessel</p>
      </div>
    </div>
  );
};

const CravingCrusher = ({ onWin, onClose }: { onWin: () => void; onClose: () => void }) => {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [emojis, setEmojis] = useState<Emoji[]>([]);
  const gameRef = useRef<HTMLDivElement>(null);
  const requestRef = useRef<number>(null);

  const spawnEmoji = useCallback(() => {
    const types: ('good' | 'bad')[] = ['good', 'good', 'bad', 'bad', 'bad'];
    const type = types[Math.floor(Math.random() * types.length)];
    const chars = type === 'good' ? ['🍎', '🥦', '💧'] : ['🍩', '🍦', '🥤'];
    
    return {
      id: Math.random(),
      type,
      char: chars[Math.floor(Math.random() * chars.length)],
      x: Math.random() * 80 + 10, // 10% to 90%
      y: -10,
      speed: Math.random() * 1 + 1,
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const update = () => {
      setEmojis((prev) => {
        const next = prev
          .map((e) => ({ ...e, y: e.y + e.speed }))
          .filter((e) => e.y < 110);
        
        if (Math.random() < 0.05 && next.length < 10) {
          next.push(spawnEmoji());
        }
        return next;
      });
      requestRef.current = requestAnimationFrame(update);
    };
    requestRef.current = requestAnimationFrame(update);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [spawnEmoji]);

  const handleCatch = (emoji: Emoji) => {
    if (emoji.type === 'good') {
      setScore((s) => s + 10);
    } else {
      setScore((s) => Math.max(0, s - 20));
    }
    setEmojis((prev) => prev.filter((e) => e.id !== emoji.id));
  };

  useEffect(() => {
    if (timeLeft === 0) {
      if (score >= 100) {
        onWin();
      } else {
        alert(`Game Over! You needed 100 points but got ${score}. Try again!`);
        onClose();
      }
    }
  }, [timeLeft, score, onWin, onClose]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-slate-950 flex flex-col"
    >
      <div className="p-4 flex justify-between items-center bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-4">
          <div className="text-amber-500 font-bold text-xl">SCORE: {score}</div>
          <div className="text-slate-400">TARGET: 100</div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-red-500 font-mono text-2xl">{timeLeft}s</div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white">
            <X />
          </button>
        </div>
      </div>

      <div ref={gameRef} className="flex-1 relative overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 to-slate-950">
        <AnimatePresence>
          {emojis.map((emoji) => (
            <motion.button
              key={emoji.id}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
              onClick={() => handleCatch(emoji)}
              className="absolute text-4xl cursor-pointer select-none p-2"
              style={{ left: `${emoji.x}%`, top: `${emoji.y}%` }}
            >
              {emoji.char}
            </motion.button>
          ))}
        </AnimatePresence>

        <div className="absolute bottom-10 left-0 right-0 text-center pointer-events-none">
          <p className="text-slate-500 text-sm uppercase tracking-widest">Tap the healthy foods!</p>
        </div>
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [gameState, setGameState] = useState<GameState>(() => {
    const saved = localStorage.getItem('sugar_slayer_state');
    if (saved) return JSON.parse(saved);
    return {
      startDate: null,
      xp: 0,
      health: 100,
      defeatedEnemies: [],
      buffUntil: null,
      checkIns: [],
    };
  });

  const [activeTab, setActiveTab] = useState<'home' | 'game' | 'enemies' | 'journal'>('home');
  const [showGame, setShowGame] = useState(false);
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  useEffect(() => {
    localStorage.setItem('sugar_slayer_state', JSON.stringify(gameState));
  }, [gameState]);

  const startQuest = () => {
    setGameState(prev => ({ ...prev, startDate: new Date().toISOString(), checkIns: [] }));
  };

  const resetQuest = () => {
    setShowResetConfirm(true);
  };

  const confirmReset = () => {
    setGameState({
      startDate: null,
      xp: 0,
      health: 100,
      defeatedEnemies: [],
      buffUntil: null,
      checkIns: [],
    });
    setShowResetConfirm(false);
  };

  const toggleEnemy = (id: string, xp: number) => {
    setGameState(prev => {
      const isDefeated = prev.defeatedEnemies.includes(id);
      return {
        ...prev,
        defeatedEnemies: isDefeated 
          ? prev.defeatedEnemies.filter(e => e !== id)
          : [...prev.defeatedEnemies, id],
        xp: isDefeated ? prev.xp - xp : prev.xp + xp
      };
    });
  };

  const handleWinGame = () => {
    const buffUntil = new Date();
    buffUntil.setHours(buffUntil.getHours() + 24);
    setGameState(prev => ({ ...prev, buffUntil: buffUntil.toISOString(), xp: prev.xp + 100 }));
    setShowGame(false);
    alert("VICTORY! You've earned a 24-hour Willpower Buff and 100 XP!");
  };

  const handleSaveCheckIn = (mood: CheckIn['mood'], note: string) => {
    const newCheckIn: CheckIn = {
      date: new Date().toISOString(),
      mood,
      note
    };
    setGameState(prev => ({
      ...prev,
      checkIns: [newCheckIn, ...prev.checkIns],
      xp: prev.xp + 25 // Reward for checking in
    }));
    setShowCheckIn(false);
  };

  const calculateDays = () => {
    if (!gameState.startDate) return 0;
    const start = new Date(gameState.startDate);
    const now = new Date();
    const diff = now.getTime() - start.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  const days = calculateDays();
  const moneySaved = days * DAILY_SAVINGS;
  const isBuffActive = gameState.buffUntil && new Date(gameState.buffUntil) > new Date();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-24 selection:bg-amber-500/30">
      {/* Header */}
      <header className="p-6 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-40">
        <div className="flex justify-between items-center max-w-lg mx-auto">
          <div className="flex items-center gap-2">
            <Sword className="text-amber-500 w-6 h-6" />
            <h1 className="text-xl font-black tracking-tighter uppercase italic">SugarSlayer</h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
              <Zap className="text-amber-500 w-4 h-4" />
              <span className="text-sm font-bold">{gameState.xp} XP</span>
            </div>
            {gameState.startDate && (
              <button onClick={resetQuest} className="text-slate-500 hover:text-red-500 transition-colors">
                <RefreshCcw size={18} />
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto p-6 space-y-8">
        {!gameState.startDate ? (
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
            <div className="w-24 h-24 bg-amber-500/10 rounded-full flex items-center justify-center border-2 border-amber-500/20 animate-pulse">
              <Skull className="text-amber-500 w-12 h-12" />
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-bold">Begin Your Quest</h2>
              <p className="text-slate-400">The white poison has held you long enough. It's time to reclaim your vitality.</p>
            </div>
            <button 
              onClick={startQuest}
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-4 px-8 rounded-2xl shadow-lg shadow-amber-500/20 transition-all active:scale-95 w-full text-lg uppercase tracking-widest"
            >
              Start Day 1
            </button>
          </div>
        ) : (
          <>
            {/* Avatar Section */}
            <section className="bg-slate-900 rounded-3xl p-8 border border-slate-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4">
                {isBuffActive && (
                  <motion.div 
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="flex items-center gap-1 bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs font-bold border border-blue-500/30"
                  >
                    <Shield size={12} /> BUFF ACTIVE
                  </motion.div>
                )}
              </div>
              <Vessel days={days} />
            </section>

            {/* Stats Grid */}
            <section className="grid grid-cols-2 gap-4">
              <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex flex-col items-center justify-center space-y-1">
                <TrendingUp className="text-emerald-500 w-5 h-5" />
                <span className="text-2xl font-black text-white">{days}</span>
                <span className="text-[10px] uppercase tracking-widest text-slate-500">Days Clean</span>
                <ShareButton 
                  text={`I've been sugar-free for ${days} days on my SugarSlayer quest! ⚔️🛡️`} 
                  title="My Progress" 
                />
              </div>
              <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex flex-col items-center justify-center space-y-1">
                <Coins className="text-amber-500 w-5 h-5" />
                <span className="text-2xl font-black text-white">${moneySaved}</span>
                <span className="text-[10px] uppercase tracking-widest text-slate-500">Gold Saved</span>
              </div>
            </section>

            {/* Quote Section */}
            <MotivationalQuote />

            {/* Vitality Bar */}
            <section className="space-y-2">
              <div className="flex justify-between items-end">
                <div className="flex items-center gap-2">
                  <Heart className="text-red-500 w-4 h-4" />
                  <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Vitality</span>
                </div>
                <span className="text-xs font-bold text-slate-500">{gameState.health}/100</span>
              </div>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${gameState.health}%` }}
                  className="h-full bg-gradient-to-r from-red-600 to-red-400 shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                />
              </div>
            </section>

            {/* Emergency Button */}
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => setShowGame(true)}
                className="bg-red-500/10 hover:bg-red-500/20 border-2 border-red-500/50 text-red-500 py-4 rounded-2xl flex items-center justify-center gap-3 font-bold transition-all active:scale-95 group text-sm"
              >
                <AlertCircle size={18} className="group-hover:animate-bounce" />
                CRAVING
              </button>
              <button 
                onClick={() => setShowCheckIn(true)}
                className="bg-emerald-500/10 hover:bg-emerald-500/20 border-2 border-emerald-500/50 text-emerald-500 py-4 rounded-2xl flex items-center justify-center gap-3 font-bold transition-all active:scale-95 group text-sm"
              >
                <CalendarDays size={18} className="group-hover:scale-110 transition-transform" />
                CHECK-IN
              </button>
            </div>

            {/* Content Tabs */}
            <div className="space-y-6">
              <div className="flex gap-2 p-1 bg-slate-900 rounded-xl border border-slate-800">
                <button 
                  onClick={() => setActiveTab('home')}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'home' ? 'bg-amber-500 text-slate-950' : 'text-slate-500'}`}
                >
                  Quest
                </button>
                <button 
                  onClick={() => setActiveTab('journal')}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'journal' ? 'bg-amber-500 text-slate-950' : 'text-slate-500'}`}
                >
                  Journal
                </button>
                <button 
                  onClick={() => setActiveTab('enemies')}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'enemies' ? 'bg-amber-500 text-slate-950' : 'text-slate-500'}`}
                >
                  Bestiary
                </button>
              </div>

              {activeTab === 'home' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-amber-500">Current Quest Stage</h3>
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
                        <Sword className="text-amber-500 w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-white">
                          {days < 7 ? "The Withdrawal Wastes" : days < 21 ? "The Valley of Discipline" : "The Peak of Clarity"}
                        </h4>
                        <p className="text-xs text-slate-400 mt-1">
                          {days < 7 ? "Your body is screaming for a fix. Survive the first week to evolve." : 
                           days < 21 ? "The cravings are quieter, but the habit is still strong. Keep your guard up." : 
                           "You have mastered your biology. You are now a beacon of willpower."}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'journal' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-amber-500">Quest Journal</h3>
                  {gameState.checkIns.length === 0 ? (
                    <div className="text-center py-10 bg-slate-900/50 rounded-2xl border border-dashed border-slate-800">
                      <p className="text-slate-500 text-xs uppercase tracking-widest">No entries yet. Check in to record your journey!</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {gameState.checkIns.map((entry, i) => (
                        <div key={i} className="bg-slate-900 border border-slate-800 p-4 rounded-2xl space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                              {new Date(entry.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                            </span>
                            <div className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest ${
                              entry.mood === 'great' ? 'bg-emerald-500/20 text-emerald-400' :
                              entry.mood === 'okay' ? 'bg-amber-500/20 text-amber-400' :
                              'bg-red-500/20 text-red-400'
                            }`}>
                              {entry.mood}
                            </div>
                          </div>
                          <p className="text-sm text-slate-300">{entry.note || "No notes recorded."}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'enemies' && (
                <div className="space-y-4">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-amber-500">Hidden Enemies</h3>
                  <p className="text-xs text-slate-500">Identify these sugar-aliases in your food to gain XP.</p>
                  <div className="space-y-3">
                    {HIDDEN_ENEMIES.map(enemy => (
                      <EnemyCard 
                        key={enemy.id}
                        enemy={enemy}
                        isDefeated={gameState.defeatedEnemies.includes(enemy.id)}
                        onToggle={() => toggleEnemy(enemy.id, enemy.xp)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/80 backdrop-blur-xl border-t border-slate-800 px-6 py-4 z-40">
        <div className="max-w-lg mx-auto flex justify-around items-center">
          <button 
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'home' ? 'text-amber-500' : 'text-slate-500'}`}
          >
            <Home size={24} />
            <span className="text-[10px] uppercase font-bold tracking-tighter">Sanctuary</span>
          </button>
          <button 
            onClick={() => setShowGame(true)}
            className="flex flex-col items-center gap-1 text-slate-500 hover:text-red-500 transition-colors"
          >
            <Gamepad2 size={24} />
            <span className="text-[10px] uppercase font-bold tracking-tighter">Crusher</span>
          </button>
          <button 
            onClick={() => setActiveTab('enemies')}
            className={`flex flex-col items-center gap-1 transition-colors ${activeTab === 'enemies' ? 'text-amber-500' : 'text-slate-500'}`}
          >
            <ListChecks size={24} />
            <span className="text-[10px] uppercase font-bold tracking-tighter">Bestiary</span>
          </button>
        </div>
      </nav>

      {/* Mini Game Modal */}
      <AnimatePresence>
        {showGame && (
          <CravingCrusher 
            onWin={handleWinGame} 
            onClose={() => setShowGame(false)} 
          />
        )}
        {showCheckIn && (
          <CheckInModal 
            onSave={handleSaveCheckIn}
            onClose={() => setShowCheckIn(false)}
          />
        )}
        {showResetConfirm && (
          <ResetConfirmationModal 
            onConfirm={confirmReset}
            onCancel={() => setShowResetConfirm(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
